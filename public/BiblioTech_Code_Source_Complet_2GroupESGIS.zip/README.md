# BiblioTech — 2GroupESGIS
## Système Complet de Gestion de Bibliothèque Universitaire

Application web développée par le collectif étudiant **2GroupESGIS** (ESGIS - École Supérieure de Gestion, d'Informatique et des Sciences).

---

### 📚 Les 4 Piliers Fonctionnels
1. **Gestion des Livres :** Inventaire, catégorisation, localisation physique par rayon (ex. *Rayon INF-A04*), suivi des stocks totaux et disponibles.
2. **Gestion des Étudiants :** Inscription libre et inclusive avec sélection du cycle (Licence 1 à Doctorat), filière au choix (IRTG, Génie Logiciel, Réseaux, Gestion, etc.), attribution d'un matricule étudiant unique.
3. **Gestion des Emprunts :** Panier de sélection d'ouvrages, réservation bloquante de 4 jours, validation de l'emprunt officiel au guichet pour 14 jours, et génération automatique de la **Quittance Officielle PDF** avec empreinte SHA-256.
4. **Gestion des Retours :** Validation physique en 1 clic, réintégration instantanée au stock disponible, calcul dynamique des pénalités en cas de retard.

---

### 🚀 Guide d'Installation & Lancement Local

#### Prérequis :
- **Node.js** (version 18 ou supérieure recommandée) : Téléchargeable gratuitement sur [nodejs.org](https://nodejs.org)
- **NPM** (inclus automatiquement avec Node.js)

#### Étapes :
1. **Extraire l'archive ZIP** dans un dossier de votre choix sur votre ordinateur.
2. **Ouvrir un terminal** (Invite de commandes, PowerShell ou Terminal macOS/Linux) dans ce dossier.
3. **Installer les dépendances :**
   ```bash
   npm install
   ```
4. **Lancer le serveur de développement :**
   ```bash
   npm run dev
   ```
5. **Ouvrir votre navigateur :**
   Rendez-vous à l'adresse indiquée dans votre terminal (habituellement `http://localhost:3000` ou `http://localhost:5173`).

---

### 🛠️ Technologies Utilisées
- **Langage :** TypeScript 5.8
- **Framework Front-end :** React 19
- **Outil de Build :** Vite 6
- **Styling :** Tailwind CSS v4
- **Génération PDF :** jsPDF
- **Icônes :** Lucide-React
