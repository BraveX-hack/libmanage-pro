import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import {
  INITIAL_BOOKS,
  INITIAL_USERS,
  INITIAL_LOANS,
  INITIAL_RESERVATIONS,
  INITIAL_LOGS,
} from './src/data/mockData';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = 3000;
const DATA_DIR = path.resolve(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'database.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Database helper functions
interface DatabaseSchema {
  users: any[];
  books: any[];
  loans: any[];
  reservations: any[];
  receipts: any[];
  activityLogs: any[];
  visitors: any[];
  transactions: any[];
  lastUpdated: string;
}

const getInitialDb = (): DatabaseSchema => ({
  users: INITIAL_USERS,
  books: INITIAL_BOOKS,
  loans: INITIAL_LOANS,
  reservations: INITIAL_RESERVATIONS,
  receipts: [],
  activityLogs: INITIAL_LOGS,
  visitors: [
    {
      id: `vis-${Date.now()}-init`,
      timestamp: new Date().toISOString(),
      action: 'visite_site',
      userName: 'WOTTO Précieux (Super Admin)',
      userEmail: 'wottoprecieux@gmail.com',
      userRole: 'super_admin',
      device: 'Serveur Central Node.js',
      ip: '127.0.0.1',
      details: 'Base de données centrale connectée et prête.',
    },
  ],
  transactions: [],
  lastUpdated: new Date().toISOString(),
});

const readDb = (): DatabaseSchema => {
  try {
    if (fs.existsSync(DB_FILE)) {
      const content = fs.readFileSync(DB_FILE, 'utf-8');
      return JSON.parse(content);
    }
  } catch (err) {
    console.error('Erreur lecture database.json:', err);
  }
  const init = getInitialDb();
  writeDb(init);
  return init;
};

const writeDb = (db: DatabaseSchema): boolean => {
  try {
    db.lastUpdated = new Date().toISOString();
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf-8');
    return true;
  } catch (err) {
    console.error('Erreur écriture database.json:', err);
    return false;
  }
};

// Initialize DB if not present
if (!fs.existsSync(DB_FILE)) {
  writeDb(getInitialDb());
  console.log('[BiblioTech] Base de données centrale créée dans /data/database.json');
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '10mb' }));

  // Serve static files from public (PDF, zip, etc.)
  app.use(express.static(path.resolve(__dirname, 'public')));

  // ==========================================
  // API ENDPOINTS - BASE DE DONNÉES CENTRALE
  // ==========================================

  // 1. État et santé du serveur
  app.get('/api/health', (_req: Request, res: Response) => {
    const db = readDb();
    res.json({
      status: 'ok',
      database: 'connected',
      filePath: '/data/database.json',
      usersCount: db.users.length,
      visitorsCount: db.visitors.length,
      loansCount: db.loans.length,
      lastUpdated: db.lastUpdated,
    });
  });

  // 2. Récupérer toute la base de données
  app.get('/api/database', (_req: Request, res: Response) => {
    const db = readDb();
    res.json(db);
  });

  // 3. Télécharger la base de données brute en JSON
  app.get('/api/database/download', (_req: Request, res: Response) => {
    if (fs.existsSync(DB_FILE)) {
      res.download(DB_FILE, 'BiblioTech_Database_2GroupESGIS.json');
    } else {
      res.status(404).json({ error: 'Fichier de base introuvable' });
    }
  });

  // 3.bis Télécharger le Grand Livre Officiel du Projet Académique en PDF (50 pages)
  app.get('/api/pdf/download', (_req: Request, res: Response) => {
    const pdfPath = path.resolve(__dirname, 'public', 'Livre_Master_Projet_Bibliotheque_50Pages_2GroupESGIS.pdf');
    if (fs.existsSync(pdfPath)) {
      res.setHeader('Content-Type', 'application/pdf');
      res.download(pdfPath, 'Livre_Master_Projet_Bibliotheque_50Pages_2GroupESGIS.pdf');
    } else {
      res.status(404).json({ error: 'Fichier PDF officiel introuvable' });
    }
  });

  // Servir les couvertures SVG et images statiques en priorité absolue
  app.use('/covers', express.static(path.resolve(__dirname, 'public', 'covers')));
  app.use('/images', express.static(path.resolve(__dirname, 'public', 'images')));
  app.use(express.static(path.resolve(__dirname, 'public')));


  // 4. Enregistrer une visite / entrée sur le site (quand un ami se connecte ou arrive)
  app.post('/api/visitors', (req: Request, res: Response) => {
    const db = readDb();
    const { userName, userEmail, userRole, userId, action = 'visite_site', device, details } = req.body;

    const clientIp = (req.headers['x-forwarded-for'] as string) || req.socket.remoteAddress || 'Anonyme';
    const userAgent = req.headers['user-agent'] || 'Inconnu';

    const newVisitor = {
      id: `vis-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      timestamp: new Date().toISOString(),
      action,
      userName: userName || 'Visiteur Externe',
      userEmail: userEmail || 'non-renseigné',
      userRole: userRole || 'visiteur',
      userId: userId || null,
      device: device || (userAgent.includes('Mobile') ? 'Smartphone' : 'Ordinateur PC/Mac'),
      ip: clientIp.split(',')[0].trim(),
      details: details || `Entrée sur l'application depuis ${userAgent.includes('Mobile') ? 'Mobile' : 'Navigateur Web'}`,
    };

    // Préfixer le visiteur (les plus récents en premier)
    db.visitors = [newVisitor, ...db.visitors.slice(0, 200)];
    writeDb(db);

    res.json({ success: true, visitor: newVisitor, totalVisitors: db.visitors.length });
  });

  // 5. Récupérer la liste des visiteurs
  app.get('/api/visitors', (_req: Request, res: Response) => {
    const db = readDb();
    res.json(db.visitors);
  });

  // 6. Inscrire ou mettre à jour un utilisateur dans la base
  app.post('/api/users', (req: Request, res: Response) => {
    const db = readDb();
    const userData = req.body;

    if (!userData || !userData.email) {
      return res.status(400).json({ error: 'Données utilisateur invalides' });
    }

    const existingIndex = db.users.findIndex((u) => u.email.toLowerCase() === userData.email.toLowerCase());

    if (existingIndex >= 0) {
      db.users[existingIndex] = { ...db.users[existingIndex], ...userData };
    } else {
      const newUser = {
        id: userData.id || `user-etu-${Date.now()}`,
        status: 'actif',
        subscriptionPlan: userData.subscriptionPlan || 'Gratuit',
        maxLoans: userData.maxLoans || 2,
        joinedDate: new Date().toISOString().split('T')[0],
        ...userData,
      };
      db.users.push(newUser);

      // Enregistrer une entrée d'inscription dans les visiteurs
      const clientIp = (req.headers['x-forwarded-for'] as string) || req.socket.remoteAddress || 'Anonyme';
      db.visitors.unshift({
        id: `vis-${Date.now()}-reg`,
        timestamp: new Date().toISOString(),
        action: 'inscription',
        userName: newUser.name,
        userEmail: newUser.email,
        userRole: newUser.role || 'etudiant',
        userId: newUser.id,
        device: 'Inscription en ligne',
        ip: clientIp.split(',')[0].trim(),
        details: `Nouvelle inscription d'un étudiant : ${newUser.name} (${newUser.filiere || 'Filière libre'}, ${newUser.academicLevel || 'Cycle'})`,
      });
    }

    writeDb(db);
    res.json({ success: true, users: db.users });
  });

  // 7. Obtenir tous les utilisateurs
  app.get('/api/users', (_req: Request, res: Response) => {
    const db = readDb();
    res.json(db.users);
  });

  // 8. Enregistrer un emprunt
  app.post('/api/loans', (req: Request, res: Response) => {
    const db = readDb();
    const newLoan = req.body;

    if (!newLoan || !newLoan.bookId) {
      return res.status(400).json({ error: 'Données d’emprunt invalides' });
    }

    db.loans.unshift(newLoan);

    // Décrémenter le stock disponible du livre dans la base
    const bookIndex = db.books.findIndex((b) => b.id === newLoan.bookId);
    if (bookIndex >= 0) {
      db.books[bookIndex].stockAvailable = Math.max(0, db.books[bookIndex].stockAvailable - 1);
    }

    // Logger la visite / action
    db.visitors.unshift({
      id: `vis-${Date.now()}-loan`,
      timestamp: new Date().toISOString(),
      action: 'emprunt',
      userName: newLoan.userName,
      userEmail: newLoan.userEmail,
      userRole: 'etudiant',
      userId: newLoan.userId,
      device: 'Système Emprunts',
      details: `Emprunt officiel de 14 jours : "${newLoan.bookTitle}" (Réf: ${newLoan.reference})`,
    });

    writeDb(db);
    res.json({ success: true, loan: newLoan, books: db.books });
  });

  // 9. Retourner un livre
  app.put('/api/loans/:id/return', (req: Request, res: Response) => {
    const db = readDb();
    const loanId = req.params.id;

    const loanIndex = db.loans.findIndex((l) => l.id === loanId);
    if (loanIndex < 0) {
      return res.status(404).json({ error: 'Emprunt introuvable' });
    }

    const loan = db.loans[loanIndex];
    loan.status = 'rendu';
    loan.returnDate = new Date().toISOString();

    // Réincrémenter le stock disponible du livre dans la base
    const bookIndex = db.books.findIndex((b) => b.id === loan.bookId);
    if (bookIndex >= 0) {
      db.books[bookIndex].stockAvailable = db.books[bookIndex].stockAvailable + 1;
    }

    // Logger
    db.visitors.unshift({
      id: `vis-${Date.now()}-return`,
      timestamp: new Date().toISOString(),
      action: 'retour',
      userName: loan.userName,
      userEmail: loan.userEmail,
      userRole: 'etudiant',
      userId: loan.userId,
      device: 'Guichet Retours',
      details: `Restitution validée : "${loan.bookTitle}". Exemplaire remis en stock (+1)`,
    });

    writeDb(db);
    res.json({ success: true, loan, books: db.books });
  });

  // 10. Enregistrer une réservation
  app.post('/api/reservations', (req: Request, res: Response) => {
    const db = readDb();
    const newReservation = req.body;

    if (!newReservation || !newReservation.bookId) {
      return res.status(400).json({ error: 'Données de réservation invalides' });
    }

    db.reservations.unshift(newReservation);

    // Décrémenter le stock disponible
    const bookIndex = db.books.findIndex((b) => b.id === newReservation.bookId);
    if (bookIndex >= 0) {
      db.books[bookIndex].stockAvailable = Math.max(0, db.books[bookIndex].stockAvailable - 1);
    }

    db.visitors.unshift({
      id: `vis-${Date.now()}-res`,
      timestamp: new Date().toISOString(),
      action: 'reservation',
      userName: newReservation.userName,
      userRole: 'etudiant',
      userId: newReservation.userId,
      device: 'Panier Réservation',
      details: `Réservation temporaire de 4 jours : "${newReservation.bookTitle}" (Réf: ${newReservation.reference})`,
    });

    writeDb(db);
    res.json({ success: true, reservation: newReservation, books: db.books });
  });

  // 11. Synchronisation bidirectionnelle client-serveur
  app.post('/api/sync', (req: Request, res: Response) => {
    const db = readDb();
    const clientData = req.body;

    // Si le client apporte de nouveaux utilisateurs locaux, on les fusionne sans écraser
    if (clientData.users && Array.isArray(clientData.users)) {
      clientData.users.forEach((clientUser: any) => {
        if (!clientUser.email) return;
        const exists = db.users.find((u) => u.email.toLowerCase() === clientUser.email.toLowerCase());
        if (!exists) {
          db.users.push(clientUser);
        }
      });
    }

    // Fusion des emprunts
    if (clientData.loans && Array.isArray(clientData.loans)) {
      clientData.loans.forEach((cl: any) => {
        const exists = db.loans.find((l) => l.id === cl.id);
        if (!exists) {
          db.loans.push(cl);
        }
      });
    }

    // Fusion des réservations
    if (clientData.reservations && Array.isArray(clientData.reservations)) {
      clientData.reservations.forEach((cr: any) => {
        const exists = db.reservations.find((r) => r.id === cr.id);
        if (!exists) {
          db.reservations.push(cr);
        }
      });
    }

    // Fusion des quittances
    if (clientData.receipts && Array.isArray(clientData.receipts)) {
      clientData.receipts.forEach((rc: any) => {
        const exists = db.receipts.find((r) => r.id === rc.id);
        if (!exists) {
          db.receipts.push(rc);
        }
      });
    }

    writeDb(db);
    res.json(db);
  });

  // ==========================================
  // VITE MIDDLEWARE (DEV) OU STATIQUE (PROD)
  // ==========================================
  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true, allowedHosts: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[BiblioTech] Serveur Full-Stack démarré sur http://0.0.0.0:${PORT}`);
    console.log(`[BiblioTech] Base de données persistante active : ${DB_FILE}`);
  });
}

startServer();
