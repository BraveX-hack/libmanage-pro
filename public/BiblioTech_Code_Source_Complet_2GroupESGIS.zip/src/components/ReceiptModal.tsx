import React, { useRef, useState } from 'react';
import { Receipt } from '../types/library';
import { useLibrary } from '../context/LibraryContext';
import { Printer, Download, CheckCircle, ShieldCheck, X, Mail, Send, Check, FileText } from 'lucide-react';
import { generateReceiptPDF } from '../utils/pdfGenerator';

interface ReceiptModalProps {
  receipt: Receipt | null;
  onClose: () => void;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({ receipt, onClose }) => {
  const receiptRef = useRef<HTMLDivElement>(null);
  const { currentUser, sendReceiptByEmail, addToast } = useLibrary();

  const [recipientEmail, setRecipientEmail] = useState(
    currentUser?.email || 'wottoprecieux@gmail.com'
  );
  const [isSendingEmail, setIsSendingEmail] = useState(false);
  const [emailSent, setEmailSent] = useState(false);

  if (!receipt) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleSendEmail = (e: React.FormEvent) => {
    e.preventDefault();
    if (!recipientEmail.trim()) return;

    setIsSendingEmail(true);
    setTimeout(() => {
      sendReceiptByEmail(receipt.id, recipientEmail.trim());
      setIsSendingEmail(false);
      setEmailSent(true);
      addToast(`Quittance ${receipt.receiptNumber} envoyée avec succès à ${recipientEmail} !`, 'success');
      setTimeout(() => setEmailSent(false), 4000);
    }, 1200);
  };

  const handleDownload = () => {
    try {
      generateReceiptPDF(receipt);
      addToast('Quittance officielle téléchargée en PDF avec succès !', 'success');
    } catch (err) {
      console.error('Erreur PDF:', err);
      window.print();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="bg-white rounded-2xl max-w-2xl w-full max-h-[95vh] overflow-hidden shadow-2xl border border-slate-200 flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top actions bar */}
        <div className="px-6 py-3.5 bg-slate-900 text-white flex items-center justify-between print:hidden">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-200">
              Quittance Officielle Certifiée
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 bg-white/10 hover:bg-white/20 text-white text-xs font-medium rounded-lg transition-colors flex items-center gap-1.5"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Imprimer</span>
            </button>
            <button
              onClick={handleDownload}
              className="px-3.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 shadow-xs"
              title="Télécharger la quittance officielle au format PDF"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Télécharger le PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1 text-slate-400 hover:text-white rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Email Dispatch Action Bar */}
        <div className="px-6 py-2.5 bg-slate-50 border-b border-slate-200 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 print:hidden">
          <div className="flex items-center gap-2 text-slate-600">
            <Mail className="w-4 h-4 text-amber-600 shrink-0" />
            <span className="font-semibold text-slate-700">Envoi par email :</span>
          </div>

          <form onSubmit={handleSendEmail} className="flex items-center gap-2 flex-1 max-w-sm">
            <input
              type="email"
              required
              value={recipientEmail}
              onChange={(e) => setRecipientEmail(e.target.value)}
              placeholder="votre.email@domaine.com"
              className="flex-1 px-2.5 py-1 text-xs border border-slate-300 rounded-lg text-slate-900 bg-white focus:outline-none focus:ring-1 focus:ring-slate-900"
            />
            <button
              type="submit"
              disabled={isSendingEmail}
              className="px-3 py-1 bg-slate-900 hover:bg-slate-800 disabled:bg-slate-300 text-white font-semibold text-xs rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap shadow-xs"
            >
              {emailSent ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Envoyé !</span>
                </>
              ) : (
                <>
                  <Send className="w-3.5 h-3.5" />
                  <span>{isSendingEmail ? 'Envoi...' : 'Envoyer'}</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Printable Quittance Document Canvas */}
        <div
          ref={receiptRef}
          className="p-8 overflow-y-auto flex-1 font-sans text-slate-900 bg-white print:p-0"
        >
          {/* Official Document Header */}
          <div className="border-b-2 border-slate-900 pb-5 mb-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-slate-900 text-amber-400 flex items-center justify-center p-1.5 overflow-hidden shadow-xs">
                  <img
                    src="/src/assets/images/library_logo_emblem_1790865075250.jpg"
                    alt="Sceau de l'Université"
                    className="w-full h-full object-contain"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div>
                  <h1 className="text-lg font-serif font-bold text-slate-950 tracking-tight uppercase">
                    ESGIS — Bibliothèque Universitaire Numérique
                  </h1>
                  <p className="text-xs text-slate-600 font-medium">
                    Projet Académique : <strong>2GroupESGIS</strong> · Tél : <span className="font-mono text-slate-800">+229 01 62 66 21 32</span>
                  </p>
                </div>
              </div>

              {/* Receipt Reference Badge */}
              <div className="text-right">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">
                  Numéro de Quittance
                </span>
                <span className="text-base font-mono font-bold text-slate-900 tracking-tight">
                  {receipt.receiptNumber}
                </span>
              </div>
            </div>

            <div className="mt-4 flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100">
              <div>
                <span className="font-semibold text-slate-700">Délivré le : </span>
                <span className="font-mono tabular-nums">
                  {new Date(receipt.createdAt).toLocaleString('fr-FR', {
                    dateStyle: 'long',
                    timeStyle: 'short',
                  })}
                </span>
              </div>
              <div className="flex items-center gap-1.5 text-emerald-700 font-semibold">
                <CheckCircle className="w-3.5 h-3.5" />
                <span>
                  {receipt.type === 'emprunt'
                    ? 'QUITTANCE D\'EMPRUNT VALIDE'
                    : receipt.type === 'paiement'
                    ? 'REÇU DE PAIEMENT ACADÉMIQUE'
                    : 'TICKET DE RÉSERVATION (4 JOURS)'}
                </span>
              </div>
            </div>
          </div>

          {/* Student Identifiers Box */}
          <div className="bg-slate-50 rounded-xl p-4 border border-slate-200/80 mb-6 text-xs grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <span className="text-slate-400 uppercase tracking-wider text-[10px] font-bold block mb-0.5">
                Bénéficiaire
              </span>
              <span className="font-bold text-slate-900 text-sm block">{receipt.userName}</span>
              <span className="text-slate-500 block mt-0.5">
                Email : {receipt.userEmail || recipientEmail}
              </span>
              <span className="text-slate-600 block mt-0.5">
                Établissement : {receipt.school || currentUser?.school || 'ESGIS'}
              </span>
            </div>
            <div>
              <span className="text-slate-400 uppercase tracking-wider text-[10px] font-bold block mb-0.5">
                Identifiant & Cursus Académique
              </span>
              <span className="font-mono font-bold text-slate-900 text-sm block">
                {receipt.studentCardNumber || currentUser?.studentCardNumber || 'ETU-2026-8841'}
              </span>
              <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                <span className="px-2 py-0.5 bg-amber-100 text-amber-900 font-bold rounded text-[11px]">
                  {receipt.academicLevel || currentUser?.academicLevel || 'Licence 2'}
                </span>
                <span className="px-2 py-0.5 bg-slate-200 text-slate-800 font-semibold rounded text-[11px]">
                  {receipt.filiere || currentUser?.filiere || 'IRTG'}
                </span>
              </div>
            </div>
          </div>

          {/* Items Table */}
          <div className="mb-6">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2">
              Désignation des Ouvrages Prêtés
            </h3>
            <div className="border border-slate-200 rounded-lg overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-3">Titre & Auteur</th>
                    <th className="py-2.5 px-3">ISBN</th>
                    <th className="py-2.5 px-3">Emplacement Rayon</th>
                    <th className="py-2.5 px-3 text-right">Date d'échéance</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium">
                  {receipt.items.map((item, idx) => (
                    <tr key={idx} className="hover:bg-slate-50/50">
                      <td className="py-3 px-3">
                        <div className="font-bold text-slate-900 font-serif">{item.title}</div>
                        <div className="text-slate-500 text-[11px]">{item.author}</div>
                      </td>
                      <td className="py-3 px-3 font-mono text-[11px] text-slate-600">
                        {item.isbn}
                      </td>
                      <td className="py-3 px-3 text-slate-600 font-mono text-[11px]">
                        {item.shelfLocation || 'Rayon Central'}
                      </td>
                      <td className="py-3 px-3 text-right font-mono font-bold text-amber-900">
                        {item.dueDate ? item.dueDate : '4 jours max'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Verification QR Code and Official Stamp */}
          <div className="pt-4 border-t-2 border-dashed border-slate-200 flex items-center justify-between gap-6">
            <div className="flex items-center gap-3">
              <div className="w-20 h-20 bg-slate-900 p-1.5 rounded-lg flex items-center justify-center shrink-0">
                <svg
                  viewBox="0 0 100 100"
                  className="w-full h-full fill-white"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <rect x="5" y="5" width="28" height="28" fill="white" />
                  <rect x="9" y="9" width="20" height="20" fill="black" />
                  <rect x="13" y="13" width="12" height="12" fill="white" />

                  <rect x="67" y="5" width="28" height="28" fill="white" />
                  <rect x="71" y="9" width="20" height="20" fill="black" />
                  <rect x="75" y="13" width="12" height="12" fill="white" />

                  <rect x="5" y="67" width="28" height="28" fill="white" />
                  <rect x="9" y="71" width="20" height="20" fill="black" />
                  <rect x="13" y="75" width="12" height="12" fill="white" />

                  <rect x="40" y="8" width="6" height="6" fill="white" />
                  <rect x="52" y="8" width="8" height="6" fill="white" />
                  <rect x="40" y="20" width="8" height="6" fill="white" />
                  <rect x="54" y="20" width="6" height="6" fill="white" />
                  <rect x="40" y="32" width="18" height="6" fill="white" />

                  <rect x="10" y="42" width="6" height="8" fill="white" />
                  <rect x="22" y="42" width="8" height="6" fill="white" />
                  <rect x="36" y="44" width="8" height="8" fill="white" />
                  <rect x="50" y="42" width="12" height="6" fill="white" />
                  <rect x="68" y="42" width="8" height="8" fill="white" />
                  <rect x="82" y="44" width="8" height="6" fill="white" />

                  <rect x="40" y="60" width="8" height="10" fill="white" />
                  <rect x="54" y="56" width="6" height="8" fill="white" />
                  <rect x="68" y="58" width="10" height="8" fill="white" />
                  <rect x="84" y="58" width="6" height="10" fill="white" />
                  <rect x="44" y="88" width="16" height="6" fill="white" />
                </svg>
              </div>

              <div>
                <div className="text-[11px] font-bold text-slate-900 uppercase">
                  Contrôle d'Intégrité Numérique
                </div>
                <div className="text-[10px] font-mono text-slate-500 break-all max-w-[240px]">
                  {receipt.securityHash}
                </div>
                <div className="text-[10px] text-emerald-700 font-semibold mt-0.5 flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3" />
                  <span>Enregistré au registre central</span>
                </div>
              </div>
            </div>

            {/* Stamp with WOTTO Précieux approval */}
            <div className="border-2 border-indigo-950 rounded-xl p-2.5 text-center text-indigo-950 rotate-[-3deg] opacity-90">
              <div className="text-[8px] font-black uppercase tracking-wider">
                2GroupESGIS · ESGIS
              </div>
              <div className="text-xs font-serif font-black tracking-tight my-0.5">
                VISA DU CONTRÔLE
              </div>
              <div className="text-[8px] font-mono">WOTTO PRÉCIEUX</div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between text-xs text-slate-500 print:hidden">
          <span>Ce document fait foi de justificatif officiel lors de la sortie de la bibliothèque.</span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 font-medium rounded-lg transition-colors"
          >
            Fermer
          </button>
        </div>
      </div>
    </div>
  );
};
