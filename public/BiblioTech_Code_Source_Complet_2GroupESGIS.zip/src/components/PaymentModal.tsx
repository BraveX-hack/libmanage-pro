import React, { useState } from 'react';
import { useLibrary } from '../context/LibraryContext';
import { SubscriptionPlan, PaymentTransaction } from '../types/library';
import { X, CheckCircle, ShieldCheck, Smartphone, CreditCard, ArrowRight, Loader2, Award } from 'lucide-react';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedPlan: SubscriptionPlan;
  amount: number;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({
  isOpen,
  onClose,
  selectedPlan,
  amount,
}) => {
  const { currentUser, upgradeSubscription, addToast } = useLibrary();

  const [paymentMethod, setPaymentMethod] = useState<'MTN MoMo' | 'Moov Money' | 'Wave' | 'Carte Bancaire'>('MTN MoMo');
  const [phoneNumber, setPhoneNumber] = useState(currentUser?.phone || '+229 01 62 66 21 32');
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvc, setCardCvc] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [transactionRef, setTransactionRef] = useState('');

  if (!isOpen) return null;

  const handlePay = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      addToast('Veuillez vous connecter pour souscrire un abonnement.', 'warning');
      return;
    }

    setIsProcessing(true);

    // Simulate realistic mobile money / bank gateway verification
    setTimeout(() => {
      const ref = 'TX-' + Math.floor(10000000 + Math.random() * 90000000);
      setTransactionRef(ref);
      setIsProcessing(false);
      setIsSuccess(true);

      upgradeSubscription(selectedPlan, {
        method: paymentMethod,
        ref,
        amount,
      });

      addToast(`Paiement de ${amount.toLocaleString('fr-FR')} FCFA validé ! Formule ${selectedPlan} activée.`, 'success');
    }, 2400);
  };

  const handleFinish = () => {
    setIsSuccess(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="bg-white rounded-2xl max-w-md w-full overflow-hidden shadow-2xl border border-slate-200 flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-600" />
            <h2 className="font-serif font-bold text-slate-900 text-lg">
              Souscription Sécurisée
            </h2>
          </div>
          {!isProcessing && (
            <button
              onClick={onClose}
              className="p-1 text-slate-400 hover:text-slate-800 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {isSuccess ? (
          <div className="p-8 text-center">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4 animate-in zoom-in-75">
              <CheckCircle className="w-9 h-9" />
            </div>
            <h3 className="text-xl font-serif font-bold text-slate-900 mb-1">
              Paiement Confirmé avec Succès !
            </h3>
            <p className="text-xs text-slate-500 mb-6">
              Votre formule <strong>{selectedPlan}</strong> est désormais active sur votre compte. Votre quota d'emprunt a été immédiatement augmenté.
            </p>

            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 text-xs font-mono text-left mb-6 space-y-1 text-slate-700">
              <div>Réf. Transaction : <strong className="text-slate-900">{transactionRef}</strong></div>
              <div>Mode de Règlement : <strong>{paymentMethod}</strong></div>
              <div>Montant Débité   : <strong className="text-emerald-700">{amount.toLocaleString('fr-FR')} FCFA</strong></div>
              <div>Bénéficiaire     : Bibliothèque Universitaire</div>
            </div>

            <button
              onClick={handleFinish}
              className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs rounded-xl transition-colors shadow-xs"
            >
              Accéder à mes Emprunts
            </button>
          </div>
        ) : isProcessing ? (
          <div className="p-12 text-center">
            <Loader2 className="w-12 h-12 text-amber-500 animate-spin mx-auto mb-4" />
            <h3 className="text-base font-serif font-bold text-slate-900 mb-1">
              Validation du Paiement en cours...
            </h3>
            <p className="text-xs text-slate-500 max-w-xs mx-auto mb-4">
              Veuillez confirmer le débit de <strong>{amount.toLocaleString('fr-FR')} FCFA</strong> sur votre téléphone via l'invite {paymentMethod}.
            </p>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-50 text-amber-800 text-[11px] font-mono rounded-full border border-amber-200">
              <span>Sécurisation cryptographique TLS 1.3</span>
            </div>
          </div>
        ) : (
          <form onSubmit={handlePay} className="p-6 text-xs space-y-5">
            {/* Selected Plan Summary */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between">
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
                  Formule Choisi
                </span>
                <span className="text-sm font-bold text-slate-900 font-serif">{selectedPlan}</span>
              </div>
              <div className="text-right">
                <span className="text-lg font-bold font-mono text-amber-800">
                  {amount.toLocaleString('fr-FR')} FCFA
                </span>
              </div>
            </div>

            {/* Payment Method Selector */}
            <div>
              <label className="block font-semibold text-slate-700 mb-2">
                Sélectionnez le mode de paiement :
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('MTN MoMo')}
                  className={`p-3 rounded-xl border text-left flex items-center gap-2.5 transition-all ${
                    paymentMethod === 'MTN MoMo'
                      ? 'border-amber-500 bg-amber-500/10 font-bold text-slate-900'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                  }`}
                >
                  <Smartphone className="w-4 h-4 text-amber-600 shrink-0" />
                  <div>
                    <div className="text-xs">MTN MoMo</div>
                    <div className="text-[10px] text-slate-400 font-normal">Mobile Money</div>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('Moov Money')}
                  className={`p-3 rounded-xl border text-left flex items-center gap-2.5 transition-all ${
                    paymentMethod === 'Moov Money'
                      ? 'border-blue-500 bg-blue-500/10 font-bold text-slate-900'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                  }`}
                >
                  <Smartphone className="w-4 h-4 text-blue-600 shrink-0" />
                  <div>
                    <div className="text-xs">Moov Money</div>
                    <div className="text-[10px] text-slate-400 font-normal">Flooz / Moov</div>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('Wave')}
                  className={`p-3 rounded-xl border text-left flex items-center gap-2.5 transition-all ${
                    paymentMethod === 'Wave'
                      ? 'border-sky-500 bg-sky-500/10 font-bold text-slate-900'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                  }`}
                >
                  <Smartphone className="w-4 h-4 text-sky-500 shrink-0" />
                  <div>
                    <div className="text-xs">Wave</div>
                    <div className="text-[10px] text-slate-400 font-normal">Scan QR ou Numéro</div>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('Carte Bancaire')}
                  className={`p-3 rounded-xl border text-left flex items-center gap-2.5 transition-all ${
                    paymentMethod === 'Carte Bancaire'
                      ? 'border-purple-500 bg-purple-500/10 font-bold text-slate-900'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                  }`}
                >
                  <CreditCard className="w-4 h-4 text-purple-600 shrink-0" />
                  <div>
                    <div className="text-xs">Carte Visa/Mastercard</div>
                    <div className="text-[10px] text-slate-400 font-normal">Paiement bancaire</div>
                  </div>
                </button>
              </div>
            </div>

            {/* Input Details */}
            {paymentMethod !== 'Carte Bancaire' ? (
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Numéro de téléphone {paymentMethod} *
                </label>
                <input
                  type="tel"
                  required
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  placeholder="+229 97 00 00 00"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-mono focus:outline-none focus:ring-2 focus:ring-slate-900"
                />
                <span className="text-[10px] text-slate-400 mt-1 block">
                  Une notification USSD push sera envoyée pour valider le débit avec votre code PIN secret.
                </span>
              </div>
            ) : (
              <div className="space-y-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Numéro de carte bancaire *
                  </label>
                  <input
                    type="text"
                    required
                    value={cardNumber}
                    onChange={(e) => setCardNumber(e.target.value)}
                    placeholder="4000 1234 5678 9010"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-mono focus:outline-none focus:ring-2 focus:ring-slate-900"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Expiration *</label>
                    <input
                      type="text"
                      required
                      value={cardExpiry}
                      onChange={(e) => setCardExpiry(e.target.value)}
                      placeholder="MM/AA"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-mono focus:outline-none focus:ring-2 focus:ring-slate-900"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">CVC / Cryptogramme *</label>
                    <input
                      type="password"
                      required
                      maxLength={4}
                      value={cardCvc}
                      onChange={(e) => setCardCvc(e.target.value)}
                      placeholder="•••"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-mono focus:outline-none focus:ring-2 focus:ring-slate-900"
                    />
                  </div>
                </div>
              </div>
            )}

            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl transition-all shadow-md flex items-center justify-center gap-2"
              >
                <span>Payer {amount.toLocaleString('fr-FR')} FCFA</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            <div className="flex items-center justify-center gap-1.5 text-[10px] text-slate-400 pt-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>Passerelle certifiée PCI-DSS & chiffrement bancaire de bout en bout</span>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
