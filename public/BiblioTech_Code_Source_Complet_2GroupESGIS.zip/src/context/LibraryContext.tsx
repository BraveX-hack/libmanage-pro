import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Book,
  User,
  Loan,
  Reservation,
  Receipt,
  ActivityLog,
  UserRole,
  SubscriptionPlan,
  PaymentTransaction,
  VisitorSession,
} from '../types/library';
import {
  INITIAL_BOOKS,
  INITIAL_USERS,
  INITIAL_LOANS,
  INITIAL_RESERVATIONS,
  INITIAL_LOGS,
} from '../data/mockData';

interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info' | 'warning';
  message: string;
}

interface LibraryContextType {
  currentUser: User | null;
  users: User[];
  books: Book[];
  loans: Loan[];
  reservations: Reservation[];
  receipts: Receipt[];
  activityLogs: ActivityLog[];
  cart: string[];
  activeReceipt: Receipt | null;
  toasts: ToastMessage[];
  transactions: PaymentTransaction[];
  visitors: VisitorSession[];
  refreshDatabase: () => Promise<void>;
  downloadDatabaseJson: () => void;

  // Role & Auth
  setCurrentUser: (user: User | null) => void;
  switchRole: (role: UserRole) => void;
  loginUser: (email: string, password?: string) => boolean;
  registerUser: (data: {
    lastName: string;
    firstName: string;
    email: string;
    school: string;
    nationalIdCard: string;
    birthDate: string;
    academicLevel?: string;
    filiere?: string;
    password?: string;
  }) => boolean;
  logoutUser: () => void;
  updateUserStatus: (userId: string, status: 'actif' | 'suspendu') => void;
  updateUserRole: (userId: string, newRole: UserRole) => void;

  // Payments & Subscriptions
  upgradeSubscription: (
    plan: SubscriptionPlan,
    paymentDetails: { method: PaymentTransaction['paymentMethod']; ref: string; amount: number }
  ) => void;

  // Books
  addBook: (bookData: Omit<Book, 'id' | 'rating' | 'reviewsCount' | 'isArchived'>) => void;
  updateBook: (id: string, updates: Partial<Book>) => void;
  archiveBook: (id: string) => { success: boolean; error?: string };
  restoreBook: (id: string) => void;

  // Loans & Returns
  borrowBook: (bookId: string, durationDays?: number) => { success: boolean; receipt?: Receipt; error?: string };
  returnBook: (loanId: string) => { success: boolean; error?: string };
  renewLoan: (loanId: string) => { success: boolean; error?: string };

  // Reservations
  reserveBook: (bookId: string) => { success: boolean; receipt?: Receipt; error?: string };
  cancelReservation: (resId: string) => { success: boolean; error?: string };
  pickupReservation: (resId: string) => { success: boolean; receipt?: Receipt; error?: string };

  // Cart
  addToCart: (bookId: string) => { success: boolean; error?: string };
  removeFromCart: (bookId: string) => void;
  clearCart: () => void;
  checkoutCart: () => { success: boolean; receipt?: Receipt; error?: string };

  // Receipts
  setActiveReceipt: (receipt: Receipt | null) => void;
  generateLoanReceipt: (loan: Loan) => Receipt;
  generateReservationReceipt: (res: Reservation) => Receipt;
  sendReceiptByEmail: (receiptId: string, email: string) => void;

  // Toast
  addToast: (message: string, type?: 'success' | 'error' | 'info' | 'warning') => void;
  removeToast: (id: string) => void;

  // Reset to initial demo data
  resetDemoData: () => void;
}

const LibraryContext = createContext<LibraryContextType | undefined>(undefined);

// Input sanitization against XSS & script injection
const sanitize = (str: string): string => {
  return str.replace(/[<>]/g, '').trim();
};

const REAL_BOOK_COVERS: Record<string, string> = {
  'book-1': '/images/book-1.jpg',
  'book-2': '/images/book-2.jpg',
  'book-3': '/images/book-3.jpg',
  'book-4': '/images/book-4.jpg',
  'book-5': '/images/book-5.jpg',
  'book-6': '/images/book-6.jpg',
  'book-7': '/images/book-7.jpg',
  'book-8': '/images/book-8.jpg',
};

const sanitizeBooks = (list: Book[]): Book[] => {
  return list.map((b) => ({
    ...b,
    coverUrl: REAL_BOOK_COVERS[b.id] || b.coverUrl || `/images/${b.id}.jpg`,
  }));
};

export const LibraryProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [users, setUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem('bibliotech_users_v2');
    return saved ? JSON.parse(saved) : INITIAL_USERS;
  });

  // Default: New visitors arrive as visitors/students, NOT logged in as admin!
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    try {
      localStorage.removeItem('bibliotech_current_user_v2'); // Clean old admin auto-login
      const savedUser = localStorage.getItem('bibliotech_current_user_v3');
      if (savedUser) return JSON.parse(savedUser);
    } catch (e) {
      // ignore
    }
    return null; // Guest/visitor state by default
  });

  const [books, setBooks] = useState<Book[]>(() => {
    try {
      const saved = localStorage.getItem('bibliotech_books_v3');
      if (saved) return sanitizeBooks(JSON.parse(saved));
    } catch (e) {}
    return sanitizeBooks(INITIAL_BOOKS);
  });

  const [loans, setLoans] = useState<Loan[]>(() => {
    const saved = localStorage.getItem('bibliotech_loans_v3');
    const raw = saved ? JSON.parse(saved) : INITIAL_LOANS;
    return raw.map((l: Loan) => ({
      ...l,
      bookCover: REAL_BOOK_COVERS[l.bookId] || l.bookCover || `/images/${l.bookId}.jpg`,
    }));
  });

  const [reservations, setReservations] = useState<Reservation[]>(() => {
    const saved = localStorage.getItem('bibliotech_reservations_v3');
    const raw = saved ? JSON.parse(saved) : INITIAL_RESERVATIONS;
    return raw.map((r: Reservation) => ({
      ...r,
      bookCover: REAL_BOOK_COVERS[r.bookId] || r.bookCover || `/images/${r.bookId}.jpg`,
    }));
  });

  const [receipts, setReceipts] = useState<Receipt[]>(() => {
    const saved = localStorage.getItem('bibliotech_receipts_v2');
    return saved ? JSON.parse(saved) : [];
  });

  const [transactions, setTransactions] = useState<PaymentTransaction[]>(() => {
    const saved = localStorage.getItem('bibliotech_transactions_v2');
    return saved ? JSON.parse(saved) : [];
  });

  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>(() => {
    const saved = localStorage.getItem('bibliotech_logs_v2');
    return saved ? JSON.parse(saved) : INITIAL_LOGS;
  });

  const [cart, setCart] = useState<string[]>(() => {
    const saved = localStorage.getItem('bibliotech_cart_v2');
    return saved ? JSON.parse(saved) : [];
  });

  const [visitors, setVisitors] = useState<VisitorSession[]>([]);
  const [activeReceipt, setActiveReceipt] = useState<Receipt | null>(null);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Synchronisation avec la Base de Données Centrale Serveur (/data/database.json)
  const refreshDatabase = async () => {
    try {
      const res = await fetch('/api/database');
      if (res.ok) {
        const data = await res.json();
        if (data.users && Array.isArray(data.users)) setUsers(data.users);
        if (data.books && Array.isArray(data.books)) setBooks(sanitizeBooks(data.books));
        if (data.loans && Array.isArray(data.loans))
          setLoans(
            data.loans.map((l: Loan) => ({
              ...l,
              bookCover: REAL_BOOK_COVERS[l.bookId] || l.bookCover || `/images/${l.bookId}.jpg`,
            }))
          );
        if (data.reservations && Array.isArray(data.reservations))
          setReservations(
            data.reservations.map((r: Reservation) => ({
              ...r,
              bookCover: REAL_BOOK_COVERS[r.bookId] || r.bookCover || `/images/${r.bookId}.jpg`,
            }))
          );
        if (data.receipts && Array.isArray(data.receipts)) setReceipts(data.receipts);
        if (data.activityLogs && Array.isArray(data.activityLogs)) setActivityLogs(data.activityLogs);
        if (data.visitors && Array.isArray(data.visitors)) setVisitors(data.visitors);
      }
    } catch {
      // Mode secours / hors ligne
    }
  };

  const downloadDatabaseJson = () => {
    const link = document.createElement('a');
    link.href = '/api/database/download';
    link.setAttribute('download', 'BiblioTech_Database_2GroupESGIS.json');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Enregistrement automatique de l'entrée de chaque utilisateur dans la base de données
  useEffect(() => {
    // 1. Charger immédiatement les données fraîches du serveur
    refreshDatabase();

    // 2. Notifier le serveur de l'entrée de cet usager/ami
    try {
      fetch('/api/visitors', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: currentUser ? 'connexion' : 'visite_site',
          userName: currentUser ? currentUser.name : 'Visiteur en ligne',
          userEmail: currentUser ? currentUser.email : 'non-connecté',
          userRole: currentUser ? currentUser.role : 'visiteur',
          userId: currentUser ? currentUser.id : null,
          details: currentUser
            ? `Utilisateur connecté : ${currentUser.name} (${currentUser.role})`
            : 'Nouvel utilisateur / ami connecté à l\'application',
        }),
      }).catch(() => {});
    } catch {
      // Ignorer
    }

    // 3. Polling toutes les 3,5 secondes pour que l'Admin voie les nouveaux arrivants et inscriptions EN DIRECT
    const interval = setInterval(() => {
      refreshDatabase();
    }, 3500);

    return () => clearInterval(interval);
  }, [currentUser?.id]);


  // Persistent storage
  useEffect(() => {
    localStorage.setItem('bibliotech_users_v2', JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('bibliotech_current_user_v3', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('bibliotech_current_user_v3');
    }
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('bibliotech_books_v2', JSON.stringify(books));
  }, [books]);

  useEffect(() => {
    localStorage.setItem('bibliotech_loans_v2', JSON.stringify(loans));
  }, [loans]);

  useEffect(() => {
    localStorage.setItem('bibliotech_reservations_v2', JSON.stringify(reservations));
  }, [reservations]);

  useEffect(() => {
    localStorage.setItem('bibliotech_receipts_v2', JSON.stringify(receipts));
  }, [receipts]);

  useEffect(() => {
    localStorage.setItem('bibliotech_transactions_v2', JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem('bibliotech_logs_v2', JSON.stringify(activityLogs));
  }, [activityLogs]);

  useEffect(() => {
    localStorage.setItem('bibliotech_cart_v2', JSON.stringify(cart));
  }, [cart]);

  // Toast
  const addToast = (message: string, type: 'success' | 'error' | 'info' | 'warning' = 'info') => {
    const id = Date.now().toString() + Math.random().toString().slice(2, 6);
    setToasts((prev) => [...prev, { id, type, message }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const logActivity = (action: string, target: string, details: string) => {
    const newLog: ActivityLog = {
      id: 'log-' + Date.now(),
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16),
      actorName: currentUser ? currentUser.name : 'Visiteur Anonyme',
      actorRole: currentUser ? currentUser.role : 'visiteur',
      action,
      target,
      details,
      ipAddress: '197.234.221.' + Math.floor(10 + Math.random() * 80),
    };
    setActivityLogs((prev) => [newLog, ...prev]);
  };

  // Quick switch role
  const switchRole = (role: UserRole) => {
    if (role === 'visiteur') {
      setCurrentUser(null);
      addToast('Session déconnectée (Mode visiteur)', 'info');
      return;
    }
    const matched = users.find((u) => u.role === role);
    if (matched) {
      setCurrentUser(matched);
      addToast(`Connecté en tant que ${matched.name} (${role.replace('_', ' ')})`, 'success');
      logActivity('Changement de Rôle', role, `Session active : ${matched.name}`);
    }
  };

  // Login with security checks
  const loginUser = (email: string, password?: string): boolean => {
    const cleanEmail = sanitize(email).toLowerCase();
    const user = users.find((u) => u.email.toLowerCase() === cleanEmail);

    if (!user) {
      addToast('Adresse email introuvable dans le registre.', 'error');
      logActivity('Tentative de Connexion Échouée', cleanEmail, 'Compte inexistant');
      return false;
    }

    if (user.status === 'suspendu') {
      addToast('Ce compte est actuellement suspendu. Contactez WOTTO Précieux.', 'error');
      logActivity('Tentative sur Compte Suspendu', user.email, 'Accès bloqué');
      return false;
    }

    setCurrentUser(user);
    addToast(`Bienvenue, ${user.name} ! Session chiffrée active.`, 'success');
    logActivity('Connexion Réussie', user.email, `Rôle ${user.role} vérifié`);
    return true;
  };

  // Registration for group members and friends
  const registerUser = (data: {
    lastName: string;
    firstName: string;
    email: string;
    school: string;
    nationalIdCard: string;
    birthDate: string;
    academicLevel?: string;
    filiere?: string;
    password?: string;
  }): boolean => {
    const cleanLastName = sanitize(data.lastName);
    const cleanFirstName = sanitize(data.firstName);
    const fullName = `${cleanLastName} ${cleanFirstName}`.trim();
    const cleanEmail = sanitize(data.email).toLowerCase();

    const exists = users.some((u) => u.email.toLowerCase() === cleanEmail);
    if (exists) {
      addToast('Un compte est déjà associé à cet email.', 'error');
      return false;
    }

    const academicLevel = sanitize(data.academicLevel || 'Licence 2');
    const filiere = sanitize(data.filiere || 'IRTG');
    const newStudentCard = `ETU-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const newUser: User = {
      id: 'user-' + Date.now(),
      name: fullName,
      firstName: cleanFirstName,
      email: cleanEmail,
      role: 'etudiant',
      studentCardNumber: newStudentCard,
      nationalIdCard: sanitize(data.nationalIdCard),
      birthDate: data.birthDate,
      school: sanitize(data.school),
      academicLevel,
      filiere,
      faculty: `${sanitize(data.school)} — ${academicLevel} (${filiere})`,
      subscriptionPlan: 'Gratuit',
      maxLoans: 2,
      status: 'actif',
      phone: '+229 01 ' + Math.floor(100000 + Math.random() * 900000),
      joinedDate: new Date().toISOString().slice(0, 10),
      passwordHash: '$argon2id$v=19$m=65536,t=4,p=2$' + Math.random().toString(36).substring(2, 15),
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
    };

    setUsers((prev) => [...prev, newUser]);
    setCurrentUser(newUser);

    // Sauvegarder immédiatement l'utilisateur dans la base de données centrale serveur
    fetch('/api/users', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newUser),
    }).catch(() => {});

    addToast(`Bienvenue ${fullName} (${academicLevel} - ${filiere}) ! Carte n° ${newUser.studentCardNumber}`, 'success');
    logActivity('Nouvelle Inscription', newUser.name, `Carte ${newUser.studentCardNumber} (${newUser.academicLevel} ${newUser.filiere})`);
    return true;
  };

  const logoutUser = () => {
    if (currentUser) {
      logActivity('Déconnexion', currentUser.name, 'Fermeture de la session sécurisée');
    }
    setCurrentUser(null);
    addToast('Session fermée en toute sécurité.', 'info');
  };

  const updateUserStatus = (userId: string, status: 'actif' | 'suspendu') => {
    setUsers((prev) => prev.map((u) => (u.id === userId ? { ...u, status } : u)));
    if (currentUser && currentUser.id === userId) {
      setCurrentUser((prev) => (prev ? { ...prev, status } : null));
    }
    addToast(`Statut mis à jour : ${status}`, 'info');
    logActivity('Mise à jour Compte', userId, `Statut passé à ${status}`);
  };

  const updateUserRole = (userId: string, newRole: UserRole) => {
    setUsers((prev) => prev.map((u) => (u.id === userId ? { ...u, role: newRole } : u)));
    if (currentUser && currentUser.id === userId) {
      setCurrentUser((prev) => (prev ? { ...prev, role: newRole } : null));
    }
    addToast(`Rôle mis à jour : ${newRole}`, 'success');
    logActivity('Changement de Rôle', userId, `Attribution du rôle ${newRole}`);
  };

  // Upgrade Subscription with real payment record
  const upgradeSubscription = (
    plan: SubscriptionPlan,
    paymentDetails: { method: PaymentTransaction['paymentMethod']; ref: string; amount: number }
  ) => {
    if (!currentUser) return;

    let newMaxLoans = 2;
    if (plan === 'Étudiant Plus') newMaxLoans = 5;
    if (plan === 'Recherche & Doctorat') newMaxLoans = 15;

    const newTx: PaymentTransaction = {
      id: 'tx-' + Date.now(),
      transactionRef: paymentDetails.ref,
      userId: currentUser.id,
      userName: currentUser.name,
      plan,
      amount: paymentDetails.amount,
      currency: 'FCFA',
      paymentMethod: paymentDetails.method,
      status: 'succes',
      date: new Date().toISOString(),
    };

    setTransactions((prev) => [newTx, ...prev]);

    // Update user plan & quota
    const updatedUser: User = {
      ...currentUser,
      subscriptionPlan: plan,
      maxLoans: newMaxLoans,
    };

    setCurrentUser(updatedUser);
    setUsers((prev) => prev.map((u) => (u.id === currentUser.id ? updatedUser : u)));

    // Generate Payment Receipt
    const paymentReceipt: Receipt = {
      id: 'rcpt-pay-' + Date.now(),
      receiptNumber: `QUITT-PAY-${new Date().getFullYear()}-${Math.floor(10000 + Math.random() * 90000)}`,
      type: 'paiement',
      createdAt: new Date().toISOString(),
      userId: currentUser.id,
      userName: currentUser.name,
      userEmail: currentUser.email,
      studentCardNumber: currentUser.studentCardNumber,
      items: [
        {
          bookId: 'sub-plan',
          title: `Souscription Formule ${plan} (${paymentDetails.amount} FCFA)`,
          author: `Règlement via ${paymentDetails.method}`,
          isbn: `REF:${paymentDetails.ref}`,
        },
      ],
      amountPaid: paymentDetails.amount,
      paymentMethod: paymentDetails.method,
      securityHash: 'SHA256:' + Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15),
      operatorName: 'Banque d\'Accueil & Comptabilité Universitaire',
    };

    setReceipts((prev) => [paymentReceipt, ...prev]);
    setActiveReceipt(paymentReceipt);

    logActivity('Paiement Validé', paymentDetails.ref, `Souscription ${plan} (${paymentDetails.amount} FCFA) par ${currentUser.name}`);
  };

  // Books CRUD
  const addBook = (bookData: Omit<Book, 'id' | 'rating' | 'reviewsCount' | 'isArchived'>) => {
    const newBook: Book = {
      ...bookData,
      title: sanitize(bookData.title),
      author: sanitize(bookData.author),
      id: 'book-' + Date.now(),
      rating: 5.0,
      reviewsCount: 1,
      isArchived: false,
    };
    setBooks((prev) => [newBook, ...prev]);
    addToast(`Livre "${newBook.title}" ajouté au catalogue.`, 'success');
    logActivity('Ajout de Livre', newBook.title, `ISBN ${newBook.isbn}, Stock: ${newBook.stockTotal}`);
  };

  const updateBook = (id: string, updates: Partial<Book>) => {
    setBooks((prev) => prev.map((b) => (b.id === id ? { ...b, ...updates } : b)));
    addToast('Notice mise à jour avec succès.', 'success');
    logActivity('Modification Livre', id, `Mise à jour`);
  };

  const archiveBook = (id: string) => {
    const hasActiveLoans = loans.some((l) => l.bookId === id && l.status !== 'rendu');
    if (hasActiveLoans) {
      addToast('Impossible d\'archiver : des exemplaires sont en cours d\'emprunt.', 'error');
      return { success: false, error: 'Emprunts en cours' };
    }
    setBooks((prev) => prev.map((b) => (b.id === id ? { ...b, isArchived: true } : b)));
    addToast('Livre retiré de la consultation publique.', 'info');
    logActivity('Archivage Livre', id, 'Livre archivé');
    return { success: true };
  };

  const restoreBook = (id: string) => {
    setBooks((prev) => prev.map((b) => (b.id === id ? { ...b, isArchived: false } : b)));
    addToast('Livre restauré dans le catalogue public.', 'success');
    logActivity('Restauration Livre', id, 'Livre restauré');
  };

  // Receipt generators
  const generateLoanReceipt = (loan: Loan): Receipt => {
    const receiptNum = `QUITT-${new Date().getFullYear()}-${Math.floor(10000 + Math.random() * 90000)}`;
    const securityHash = 'SHA256:' + Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
    const newReceipt: Receipt = {
      id: 'rcpt-' + Date.now(),
      receiptNumber: receiptNum,
      type: 'emprunt',
      createdAt: new Date().toISOString(),
      userId: loan.userId,
      userName: loan.userName,
      userEmail: loan.userEmail,
      studentCardNumber: loan.studentCardNumber,
      academicLevel: currentUser?.academicLevel || 'Licence 2',
      filiere: currentUser?.filiere || 'IRTG',
      school: currentUser?.school || 'ESGIS',
      items: [
        {
          bookId: loan.bookId,
          title: loan.bookTitle,
          author: loan.bookAuthor,
          isbn: loan.isbn,
          dueDate: loan.dueDate,
        },
      ],
      securityHash,
      operatorName: 'WOTTO Précieux — 2GroupESGIS (Concepteur & Direction)',
    };
    setReceipts((prev) => [newReceipt, ...prev]);
    return newReceipt;
  };

  const generateReservationReceipt = (res: Reservation): Receipt => {
    const receiptNum = `TICK-${new Date().getFullYear()}-${Math.floor(10000 + Math.random() * 90000)}`;
    const securityHash = 'SHA256:' + Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
    const newReceipt: Receipt = {
      id: 'rcpt-' + Date.now(),
      receiptNumber: receiptNum,
      type: 'reservation',
      createdAt: new Date().toISOString(),
      userId: res.userId,
      userName: res.userName,
      userEmail: currentUser?.email,
      studentCardNumber: currentUser?.studentCardNumber,
      academicLevel: currentUser?.academicLevel || 'Licence 2',
      filiere: currentUser?.filiere || 'IRTG',
      school: currentUser?.school || 'ESGIS',
      items: [
        {
          bookId: res.bookId,
          title: res.bookTitle,
          author: res.bookAuthor,
          isbn: res.isbn,
        },
      ],
      expiresAt: res.expiresAt,
      securityHash,
      operatorName: 'WOTTO Précieux — 2GroupESGIS (Guichet Réservations)',
    };
    setReceipts((prev) => [newReceipt, ...prev]);
    return newReceipt;
  };

  // Send receipt by email
  const sendReceiptByEmail = (receiptId: string, email: string) => {
    const cleanEmail = sanitize(email);
    const sentAt = new Date().toISOString();
    setReceipts((prev) =>
      prev.map((r) => (r.id === receiptId ? { ...r, emailSentTo: cleanEmail, emailSentAt: sentAt } : r))
    );
    logActivity('Envoi Quittance par Email', cleanEmail, `Quittance ${receiptId} transmise avec succès`);
  };

  // Rule verification
  const checkCanBorrow = (user: User): { allowed: boolean; reason?: string } => {
    if (user.status === 'suspendu') {
      return { allowed: false, reason: 'Votre compte est suspendu. Veuillez voir WOTTO Précieux.' };
    }
    const userActiveLoans = loans.filter((l) => l.userId === user.id && l.status !== 'rendu');
    const hasLate = userActiveLoans.some((l) => l.status === 'en_retard');
    if (hasLate) {
      return { allowed: false, reason: 'Règle stricte : Vous avez un livre en retard. Restituez-le d\'abord pour débloquer votre compte.' };
    }
    if (userActiveLoans.length >= user.maxLoans) {
      return { allowed: false, reason: `Quota atteint (${user.maxLoans} livres max pour la formule ${user.subscriptionPlan}). Passez à Étudiant Plus pour emprunter davantage.` };
    }
    return { allowed: true };
  };

  // Borrow Book
  const borrowBook = (bookId: string, durationDays = 14) => {
    if (!currentUser) {
      addToast('Veuillez vous connecter pour emprunter un livre.', 'warning');
      return { success: false, error: 'Non authentifié' };
    }
    const check = checkCanBorrow(currentUser);
    if (!check.allowed) {
      addToast(check.reason || 'Emprunt refusé.', 'error');
      return { success: false, error: check.reason };
    }

    const book = books.find((b) => b.id === bookId);
    if (!book) return { success: false, error: 'Livre non trouvé' };

    if (book.stockAvailable <= 0) {
      addToast('Rupture de stock temporaire. Vous pouvez le réserver pour son retour.', 'error');
      return { success: false, error: 'Rupture de stock' };
    }

    setBooks((prev) =>
      prev.map((b) => (b.id === bookId ? { ...b, stockAvailable: Math.max(0, b.stockAvailable - 1) } : b))
    );

    const now = new Date();
    const due = new Date();
    due.setDate(now.getDate() + durationDays);

    const newLoan: Loan = {
      id: 'loan-' + Date.now(),
      reference: `EMP-${now.getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
      userId: currentUser.id,
      userName: currentUser.name,
      userEmail: currentUser.email,
      studentCardNumber: currentUser.studentCardNumber,
      bookId: book.id,
      bookTitle: book.title,
      bookAuthor: book.author,
      bookCover: book.coverUrl,
      isbn: book.isbn,
      borrowDate: now.toISOString().slice(0, 10),
      dueDate: due.toISOString().slice(0, 10),
      status: 'en_cours',
      renewalCount: 0,
      dailyLateFee: 200,
    };

    setLoans((prev) => [newLoan, ...prev]);

    // Sauvegarder dans la base centrale serveur
    fetch('/api/loans', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newLoan),
    }).catch(() => {});

    const receipt = generateLoanReceipt(newLoan);
    // Do not force-open receipt pop-up aggressively
    addToast(`Emprunt validé ! Quittance n° ${receipt.receiptNumber} émise.`, 'success');
    logActivity('Nouvel Emprunt', newLoan.reference, `"${book.title}" prêté à ${currentUser.name} (échéance: ${newLoan.dueDate})`);

    return { success: true, receipt };
  };

  // Return Book
  const returnBook = (loanId: string) => {
    const loan = loans.find((l) => l.id === loanId);
    if (!loan) return { success: false, error: 'Prêt non trouvé' };

    const returnDate = new Date().toISOString().slice(0, 10);
    setLoans((prev) =>
      prev.map((l) => (l.id === loanId ? { ...l, status: 'rendu', returnDate } : l))
    );

    setBooks((prev) =>
      prev.map((b) => (b.id === loan.bookId ? { ...b, stockAvailable: Math.min(b.stockTotal, b.stockAvailable + 1) } : b))
    );

    // Mettre à jour la base centrale serveur
    fetch(`/api/loans/${loanId}/return`, {
      method: 'PUT',
    }).catch(() => {});

    addToast(`Livre "${loan.bookTitle}" restitué. Exemplaire réintégré en rayon.`, 'success');
    logActivity('Retour de Livre', loan.reference, `Retour enregistré pour "${loan.bookTitle}".`);
    return { success: true };
  };

  // Renew Loan
  const renewLoan = (loanId: string) => {
    const loan = loans.find((l) => l.id === loanId);
    if (!loan) return { success: false, error: 'Prêt introuvable' };

    if (loan.renewalCount >= 1) {
      addToast('Ce prêt a déjà été renouvelé une fois (limite maximale).', 'error');
      return { success: false, error: 'Limite atteinte' };
    }

    if (loan.status === 'en_retard') {
      addToast('Impossible de renouveler un livre déjà en retard.', 'error');
      return { success: false, error: 'Document en retard' };
    }

    const currentDue = new Date(loan.dueDate);
    currentDue.setDate(currentDue.getDate() + 14);
    const newDueDate = currentDue.toISOString().slice(0, 10);

    setLoans((prev) =>
      prev.map((l) => (l.id === loanId ? { ...l, dueDate: newDueDate, renewalCount: l.renewalCount + 1 } : l))
    );

    addToast(`Prêt prolongé de 14 jours ! Date limite : ${newDueDate}`, 'success');
    logActivity('Prolongation Prêt', loan.reference, `Prolongé jusqu'au ${newDueDate} par ${currentUser?.name}`);
    return { success: true };
  };

  // Reserve Book (4 days)
  const reserveBook = (bookId: string) => {
    if (!currentUser) {
      addToast('Connectez-vous pour effectuer une réservation.', 'warning');
      return { success: false, error: 'Non authentifié' };
    }

    const book = books.find((b) => b.id === bookId);
    if (!book) return { success: false, error: 'Livre introuvable' };

    if (book.stockAvailable <= 0) {
      addToast('Tous les exemplaires sont actuellement réservés.', 'error');
      return { success: false, error: 'Indisponible' };
    }

    setBooks((prev) =>
      prev.map((b) => (b.id === bookId ? { ...b, stockAvailable: Math.max(0, b.stockAvailable - 1) } : b))
    );

    const now = new Date();
    const expires = new Date();
    expires.setDate(now.getDate() + 4);

    const newRes: Reservation = {
      id: 'res-' + Date.now(),
      reference: `RES-${now.getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
      userId: currentUser.id,
      userName: currentUser.name,
      bookId: book.id,
      bookTitle: book.title,
      bookAuthor: book.author,
      bookCover: book.coverUrl,
      isbn: book.isbn,
      reservedAt: now.toISOString(),
      expiresAt: expires.toISOString(),
      status: 'active',
      pickupDesk: 'Banque Centrale d\'accueil (Guichet 2)',
    };

    setReservations((prev) => [newRes, ...prev]);

    const receipt = generateReservationReceipt(newRes);
    // Do not force-open receipt pop-up
    addToast(`Réservation validée ! Ticket 4 jours émis.`, 'success');
    logActivity('Réservation', newRes.reference, `"${book.title}" réservé par ${currentUser.name}`);
    return { success: true, receipt };
  };

  const cancelReservation = (resId: string) => {
    const res = reservations.find((r) => r.id === resId);
    if (!res) return { success: false, error: 'Réservation introuvable' };

    setReservations((prev) =>
      prev.map((r) => (r.id === resId ? { ...r, status: 'annulee' } : r))
    );

    setBooks((prev) =>
      prev.map((b) => (b.id === res.bookId ? { ...b, stockAvailable: Math.min(b.stockTotal, b.stockAvailable + 1) } : b))
    );

    addToast('Réservation annulée. Livre remis en rayon disponible.', 'info');
    logActivity('Annulation Réservation', res.reference, `Réservation "${res.bookTitle}" annulée`);
    return { success: true };
  };

  const pickupReservation = (resId: string) => {
    const res = reservations.find((r) => r.id === resId);
    if (!res) return { success: false, error: 'Réservation introuvable' };

    setReservations((prev) =>
      prev.map((r) => (r.id === resId ? { ...r, status: 'retiree' } : r))
    );

    const now = new Date();
    const due = new Date();
    due.setDate(now.getDate() + 14);

    const newLoan: Loan = {
      id: 'loan-' + Date.now(),
      reference: `EMP-${now.getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
      userId: res.userId,
      userName: res.userName,
      userEmail: currentUser?.email || 'etudiant@univ-tech.edu',
      studentCardNumber: currentUser?.studentCardNumber,
      bookId: res.bookId,
      bookTitle: res.bookTitle,
      bookAuthor: res.bookAuthor,
      bookCover: res.bookCover,
      isbn: res.isbn,
      borrowDate: now.toISOString().slice(0, 10),
      dueDate: due.toISOString().slice(0, 10),
      status: 'en_cours',
      renewalCount: 0,
      dailyLateFee: 200,
    };

    setLoans((prev) => [newLoan, ...prev]);
    const receipt = generateLoanReceipt(newLoan);
    setActiveReceipt(receipt);

    addToast(`Retrait validé au guichet ! Quittance d'emprunt n° ${receipt.receiptNumber} émise.`, 'success');
    logActivity('Retrait Réservation', res.reference, `Livre retiré par ${res.userName}`);
    return { success: true, receipt };
  };

  // Cart
  const addToCart = (bookId: string) => {
    if (cart.includes(bookId)) {
      addToast('Ce livre est déjà dans votre panier.', 'warning');
      return { success: false, error: 'Déjà présent' };
    }
    const maxQuota = currentUser ? currentUser.maxLoans : 3;
    const currentLoansCount = loans.filter((l) => l.userId === currentUser?.id && l.status !== 'rendu').length;
    if (cart.length + currentLoansCount >= maxQuota) {
      addToast(`Quota d'emprunt (${maxQuota} livres) atteint.`, 'error');
      return { success: false, error: 'Quota dépassé' };
    }
    setCart((prev) => [...prev, bookId]);
    addToast('Livre ajouté au panier d\'emprunt.', 'success');
    return { success: true };
  };

  const removeFromCart = (bookId: string) => {
    setCart((prev) => prev.filter((id) => id !== bookId));
    addToast('Livre retiré du panier.', 'info');
  };

  const clearCart = () => {
    setCart([]);
  };

  const checkoutCart = () => {
    if (!currentUser) {
      addToast('Veuillez vous connecter pour valider votre réservation.', 'warning');
      return { success: false, error: 'Non authentifié' };
    }
    if (cart.length === 0) return { success: false, error: 'Panier vide' };

    const check = checkCanBorrow(currentUser);
    if (!check.allowed) {
      addToast(check.reason || 'Réservation refusée.', 'error');
      return { success: false, error: check.reason };
    }

    const itemsToReserve = books.filter((b) => cart.includes(b.id) && b.stockAvailable > 0);
    if (itemsToReserve.length === 0) {
      addToast('Aucun livre sélectionné n\'est actuellement disponible pour réservation.', 'error');
      return { success: false, error: 'Indisponible' };
    }

    const now = new Date();
    const expires = new Date();
    expires.setDate(now.getDate() + 4);

    const newReservations: Reservation[] = [];
    itemsToReserve.forEach((book, idx) => {
      const res: Reservation = {
        id: 'res-' + Date.now() + '-' + idx,
        reference: `RES-${now.getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
        userId: currentUser.id,
        userName: currentUser.name,
        bookId: book.id,
        bookTitle: book.title,
        bookAuthor: book.author,
        bookCover: book.coverUrl,
        isbn: book.isbn,
        reservedAt: now.toISOString(),
        expiresAt: expires.toISOString(),
        status: 'active',
        pickupDesk: 'Banque Centrale d\'accueil (Guichet 2)',
      };
      newReservations.push(res);
    });

    setBooks((prev) =>
      prev.map((b) => {
        if (itemsToReserve.some((item) => item.id === b.id)) {
          return { ...b, stockAvailable: Math.max(0, b.stockAvailable - 1) };
        }
        return b;
      })
    );

    setReservations((prev) => [...newReservations, ...prev]);

    const receiptNum = `TICK-${now.getFullYear()}-${Math.floor(10000 + Math.random() * 90000)}`;
    const securityHash = 'SHA256:' + Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
    const multiReceipt: Receipt = {
      id: 'rcpt-' + Date.now(),
      receiptNumber: receiptNum,
      type: 'reservation',
      createdAt: now.toISOString(),
      userId: currentUser.id,
      userName: currentUser.name,
      userEmail: currentUser.email,
      studentCardNumber: currentUser.studentCardNumber,
      academicLevel: currentUser.academicLevel || 'Licence 2',
      filiere: currentUser.filiere || 'IRTG',
      school: currentUser.school || 'ESGIS',
      expiresAt: expires.toISOString(),
      items: itemsToReserve.map((b) => ({
        bookId: b.id,
        title: b.title,
        author: b.author,
        isbn: b.isbn,
        shelfLocation: b.shelfLocation,
      })),
      securityHash,
      operatorName: 'WOTTO Précieux — 2GroupESGIS (Guichet Réservations)',
    };

    setReceipts((prev) => [multiReceipt, ...prev]);
    // Do NOT force open activeReceipt popup! Let CartModal handle confirmation and offer download!
    setCart([]);

    addToast(`Réservation validée pour ${itemsToReserve.length} livre(s) ! Ticket 4 jours émis.`, 'success');
    logActivity('Réservation Groupée', receiptNum, `${itemsToReserve.length} livre(s) réservé(s)`);
    return { success: true, receipt: multiReceipt };
  };

  // Reset
  const resetDemoData = () => {
    setUsers(INITIAL_USERS);
    setCurrentUser(INITIAL_USERS[0]);
    setBooks(INITIAL_BOOKS);
    setLoans(INITIAL_LOANS);
    setReservations(INITIAL_RESERVATIONS);
    setReceipts([]);
    setTransactions([]);
    setActivityLogs(INITIAL_LOGS);
    setCart([]);
    localStorage.clear();
    addToast('Données et session de WOTTO Précieux réinitialisées.', 'info');
  };

  return (
    <LibraryContext.Provider
      value={{
        currentUser,
        users,
        books,
        loans,
        reservations,
        receipts,
        activityLogs,
        cart,
        activeReceipt,
        toasts,
        transactions,
        setCurrentUser,
        switchRole,
        loginUser,
        registerUser,
        logoutUser,
        updateUserStatus,
        updateUserRole,
        upgradeSubscription,
        addBook,
        updateBook,
        archiveBook,
        restoreBook,
        borrowBook,
        returnBook,
        renewLoan,
        reserveBook,
        cancelReservation,
        pickupReservation,
        addToCart,
        removeFromCart,
        clearCart,
        checkoutCart,
        visitors,
        refreshDatabase,
        downloadDatabaseJson,
        setActiveReceipt,
        generateLoanReceipt,
        generateReservationReceipt,
        sendReceiptByEmail,
        addToast,
        removeToast,
        resetDemoData,
      }}
    >
      {children}
    </LibraryContext.Provider>
  );
};

export const useLibrary = () => {
  const context = useContext(LibraryContext);
  if (!context) {
    throw new Error('useLibrary must be used within a LibraryProvider');
  }
  return context;
};
