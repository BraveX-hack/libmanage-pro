import jsPDF from 'jspdf';
import { Receipt } from '../types/library';

export const generateReceiptPDF = (receipt: Receipt): void => {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 16;
  const contentWidth = pageWidth - margin * 2;

  // Header Background bar
  doc.setFillColor(15, 23, 42); // slate-900
  doc.rect(0, 0, pageWidth, 26, 'F');

  // University & App Title
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.text('ESGIS — BIBLIOTHÈQUE UNIVERSITAIRE NUMÉRIQUE', margin, 12);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(251, 191, 36); // amber-400
  doc.text('Système Conçu par WOTTO Précieux · Direction & Conservation Documentaire', margin, 18);

  doc.setTextColor(203, 213, 225); // slate-300
  doc.text('Tél : +229 01 62 66 21 32 · Cotonou, Bénin', margin, 22);

  // Document Badge Type on Top Right
  const isLoan = receipt.type === 'emprunt';
  const isReservation = receipt.type === 'reservation';
  const docTypeLabel = isLoan
    ? "QUITTANCE OFFICIELLE D'EMPRUNT"
    : isReservation
    ? 'TICKET DE RÉSERVATION (4 JOURS)'
    : 'REÇU DE PAIEMENT ACADÉMIQUE';

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(255, 255, 255);
  doc.text(receipt.receiptNumber, pageWidth - margin, 14, { align: 'right' });
  doc.setFontSize(7.5);
  doc.setTextColor(148, 163, 184);
  doc.text('RÉFÉRENCE UNIQUE', pageWidth - margin, 19, { align: 'right' });

  // Main Banner
  let y = 36;
  doc.setFillColor(248, 250, 252); // slate-50
  doc.setDrawColor(226, 232, 240); // slate-200
  doc.roundedRect(margin, y, contentWidth, 14, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(15, 23, 42);
  doc.text(docTypeLabel, margin + 4, y + 9);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(71, 85, 105);
  const formattedDate = new Date(receipt.createdAt).toLocaleString('fr-FR', {
    dateStyle: 'long',
    timeStyle: 'short',
  });
  doc.text(`Délivré le : ${formattedDate}`, pageWidth - margin - 4, y + 9, { align: 'right' });

  // Student Information Box
  y += 20;
  doc.setFillColor(255, 255, 255);
  doc.setDrawColor(203, 213, 225);
  doc.roundedRect(margin, y, contentWidth, 38, 2, 2, 'D');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(180, 83, 9); // amber-700
  doc.text("IDENTIFICATION DU BÉNÉFICIAIRE", margin + 5, y + 7);

  doc.setDrawColor(241, 245, 249);
  doc.line(margin + 5, y + 10, pageWidth - margin - 5, y + 10);

  // Column 1
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(71, 85, 105);
  doc.text('Nom & Prénom(s) :', margin + 5, y + 16);
  doc.text('Email Étudiant :', margin + 5, y + 22);
  doc.text('N° Carte Étudiant :', margin + 5, y + 28);
  doc.text('Établissement :', margin + 5, y + 34);

  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text(receipt.userName || 'Étudiant ESGIS', margin + 38, y + 16);

  doc.setFont('helvetica', 'normal');
  doc.text(receipt.userEmail || 'etudiant@esgis.org', margin + 38, y + 22);
  doc.setFont('courier', 'bold');
  doc.text(receipt.studentCardNumber || 'ETU-2026-8841', margin + 38, y + 28);
  doc.setFont('helvetica', 'normal');
  doc.text(receipt.school || 'ESGIS (École Supérieure de Gestion, d\'Informatique et des Sciences)', margin + 38, y + 34);

  // Column 2: Licence & Filière (Requested by user)
  const col2X = margin + 110;
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(71, 85, 105);
  doc.text('Cycle / Niveau :', col2X, y + 16);
  doc.text('Filière / Spécialité :', col2X, y + 22);
  doc.text('Statut Compte :', col2X, y + 28);

  doc.setFont('helvetica', 'bold');
  doc.setTextColor(180, 83, 9); // amber-700
  doc.text(receipt.academicLevel || 'Licence 2', col2X + 32, y + 16);

  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text(receipt.filiere || 'IRTG (Informatique & Réseaux)', col2X + 32, y + 22);

  doc.setFont('helvetica', 'bold');
  doc.setTextColor(16, 185, 129); // emerald-600
  doc.text('ACTIF & VÉRIFIÉ', col2X + 32, y + 28);

  // Books Table Header
  y += 45;
  doc.setFillColor(15, 23, 42);
  doc.rect(margin, y, contentWidth, 8, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(255, 255, 255);
  doc.text('N°', margin + 3, y + 5.5);
  doc.text('ISBN', margin + 12, y + 5.5);
  doc.text('TITRE DE L\'OUVRAGE / AUTEUR', margin + 42, y + 5.5);
  doc.text('RAYON', margin + 120, y + 5.5);
  doc.text(isReservation ? 'VALIDITÉ RÉSERVATION' : 'DATE LIMITE RETOUR', pageWidth - margin - 3, y + 5.5, { align: 'right' });

  // Books Table Rows
  y += 8;
  const items = receipt.items && receipt.items.length > 0 ? receipt.items : [];
  
  items.forEach((item, index) => {
    const isEven = index % 2 === 0;
    doc.setFillColor(isEven ? 255 : 248, isEven ? 255 : 250, isEven ? 255 : 252);
    doc.rect(margin, y, contentWidth, 12, 'F');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(71, 85, 105);
    doc.text(String(index + 1), margin + 3, y + 6);

    doc.setFont('courier', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(100, 116, 139);
    doc.text(item.isbn || 'N/A', margin + 12, y + 6);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.setTextColor(15, 23, 42);
    const truncatedTitle = item.title.length > 40 ? item.title.substring(0, 38) + '...' : item.title;
    doc.text(truncatedTitle, margin + 42, y + 5);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7);
    doc.setTextColor(100, 116, 139);
    doc.text(`Par ${item.author}`, margin + 42, y + 9);

    doc.setFont('courier', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(71, 85, 105);
    doc.text(item.shelfLocation || 'Rayon Central', margin + 120, y + 6);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    if (isReservation) {
      doc.setTextColor(180, 83, 9); // amber
      doc.text('4 jours max (au guichet)', pageWidth - margin - 3, y + 6, { align: 'right' });
    } else {
      doc.setTextColor(220, 38, 38); // red
      doc.text(item.dueDate || '14 jours', pageWidth - margin - 3, y + 6, { align: 'right' });
    }

    doc.setDrawColor(226, 232, 240);
    doc.line(margin, y + 12, pageWidth - margin, y + 12);
    y += 12;
  });

  // Regulatory Instructions Box
  y += 6;
  doc.setFillColor(254, 243, 199); // amber-100
  doc.setDrawColor(245, 158, 11); // amber-500
  doc.roundedRect(margin, y, contentWidth, 24, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(146, 64, 14); // amber-800
  doc.text('RÈGLES ET CONDITIONS DE RETRAIT UNIVERSITAIRE :', margin + 4, y + 5);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(120, 53, 15);
  doc.text(
    '• Ce document constitue votre justificatif officiel. Présentez-le sur votre téléphone ou imprimé à la banque d\'accueil.',
    margin + 4,
    y + 10
  );
  doc.text(
    isReservation
      ? '• Les ouvrages réservés sont conservés 4 jours calendaires. Au-delà, ils sont réintégrés au catalogue public.'
      : '• Durée de prêt standard : 14 jours. Tout retard entraîne une pénalité de 200 FCFA/jour et la suspension des emprunts.',
    margin + 4,
    y + 15
  );
  doc.text(
    '• Tout livre dégradé ou non restitué donnera lieu à un remboursement intégral auprès de la direction WOTTO Précieux.',
    margin + 4,
    y + 20
  );

  // Security Stamp & Signatures
  y += 30;

  // Stamp Box Left
  doc.setDrawColor(203, 213, 225);
  doc.setFillColor(248, 250, 252);
  doc.roundedRect(margin, y, 80, 26, 2, 2, 'FD');

  doc.setFont('courier', 'bold');
  doc.setFontSize(7);
  doc.setTextColor(15, 23, 42);
  doc.text('CERTIFICAT DE CONTRÔLE NUMÉRIQUE', margin + 3, y + 5);
  doc.setFont('courier', 'normal');
  doc.setFontSize(6.5);
  doc.setTextColor(100, 116, 139);
  doc.text(`Hash : ${receipt.securityHash || 'SHA256:AUTHENTIC-RECORD-ESGIS'}`, margin + 3, y + 10);
  doc.text(`Opérateur : ${receipt.operatorName || 'WOTTO Précieux'}`, margin + 3, y + 15);
  doc.text('Contrôle : INTÈGRE & VALIDÉ SANS MODIFICATION', margin + 3, y + 20);

  // Signature Box Right
  doc.setDrawColor(180, 83, 9);
  doc.setFillColor(255, 255, 255);
  doc.roundedRect(pageWidth - margin - 80, y, 80, 26, 2, 2, 'D');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(15, 23, 42);
  doc.text('DIRECTION DE LA BIBLIOTHÈQUE ESGIS', pageWidth - margin - 40, y + 5, { align: 'center' });

  doc.setFont('helvetica', 'italic');
  doc.setFontSize(8);
  doc.setTextColor(180, 83, 9);
  doc.text('WOTTO Précieux', pageWidth - margin - 40, y + 12, { align: 'center' });

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6.5);
  doc.setTextColor(100, 116, 139);
  doc.text('Signature & Sceau Officiel Autorisé', pageWidth - margin - 40, y + 17, { align: 'center' });
  doc.text('2GroupESGIS · République du Bénin', pageWidth - margin - 40, y + 21, { align: 'center' });

  // Footer bar
  doc.setFillColor(15, 23, 42);
  doc.rect(0, pageHeight - 10, pageWidth, 10, 'F');

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  doc.setTextColor(203, 213, 225);
  doc.text(
    'BiblioTech ESGIS — Document académique officiel certifié généré électroniquement.',
    pageWidth / 2,
    pageHeight - 4,
    { align: 'center' }
  );

  // Trigger real PDF download
  const filename = `${receipt.receiptNumber || 'QUITTANCE'}_ESGIS.pdf`;
  doc.save(filename);
};
